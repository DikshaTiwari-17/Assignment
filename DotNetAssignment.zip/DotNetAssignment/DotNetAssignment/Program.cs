﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day11Assignment
{
    class Program
    {
        static void dispaly(List<BookStore> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item.bookName);
            }
        }

        static void displayDescription(List<BookStore> list, int bookId)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].bookId == bookId)
                {
                    Console.WriteLine("Description of " + list[i].bookName + "\n" + list[i].bookDescription + "\n");
                }
            }
        }



        static void editDetails(List<BookStore> list, int bookId)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].bookId == bookId)
                {
                    Console.WriteLine("Enter the name of the book ");
                    string updatedBookName = Console.ReadLine();
                    list[i].bookName = updatedBookName;

                    Console.WriteLine("Enter Authors name ");
                    string updatedAuthorName = Console.ReadLine();
                    list[i].bookAuthor = updatedAuthorName;

                    Console.WriteLine("Enter description of the book ");
                    string updatedDescription = Console.ReadLine();
                    list[i].bookDescription = updatedDescription;

                    Console.WriteLine("Enter ISBN code ");
                    Int64 updatedIsbnCode = Convert.ToInt64(Console.ReadLine());
                    list[i].bookIsbnCode = updatedIsbnCode;

                    Console.WriteLine("Enter price of the book ");
                    double updatedPrice = Convert.ToDouble(Console.ReadLine());
                    list[i].price = updatedPrice;
                    Console.WriteLine("Updated Book details \n");
                    Console.WriteLine($"Book Name: {list[i].bookName} \t Author: {list[i].bookAuthor} \t ISBN code: {list[i].bookIsbnCode} \t Price: {list[i].price}" + "\nDescription: " + list[i].bookDescription + "\n \n");

                }


            }
        }

        static void deleteDetails(List<BookStore> list, int bookId)
        {

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].bookId == bookId)
                {
                    list.RemoveAt(i);
                }
            }

        }

        static void addBook(List<BookStore> list, BookStore b)
        {
            list.Add(b);

            Console.WriteLine($"Book Id: {b.bookId} \t Book Name: {b.bookName} \t Author: {b.bookAuthor} \t ISBN code: {b.bookIsbnCode} \t Price: {b.price}" + "\nDescription: " + b.bookDescription + "\n \n");
        }

        static void Main(string[] args)
        {
            List<BookStore> books = new List<BookStore>
            {
                (new BookStore(101, "The Da Vinci Code", "Dan Brown",
                "The Da Vinci Code is a mind-bending best-selling novel that offers a controversial version of the search for the Holy Grail and the life of Jesus, suggesting that Christ, the Son of God, was also a husband and a father",
                1298763409,
                499.8
                )),

                (new BookStore(102, "Harry Potter and the Deathly Hallows", "J K Rowling",
                "The title of the book refers to three mythical objects featured in the story, collectively known as the Deathly Hallows—an unbeatable wand (the Elder Wand), a stone to bring the dead to life (the Resurrection Stone), and a cloak of invisibility.",
                34321987509,
                509.70
                )),

                (new BookStore(103, "Angels and Demons", "Dan Brown",
                "The clash between science and faith is everywhere in Angels and Demons. It is symbolized through the opposing organizations of the Illuminati (who claim to speak for free thought and science) and the Catholic Church (which bulwarks two millennia of dedication to the Christian faith)",
                5610982341,
                987.99
                )),

                (new BookStore(104, "Twilight", "Stephenie Meyer",
                "Twilight is a series of fantasy romance novels by Stephenie Meyer. It follows the life of Isabella Bella Swan, a human teenager who moves to Forks, Washington and finds her life turned upside-down when she falls in love with a vampire named Edward Cullen",
                9844512222,
                567.89
                ))
            };


            int input;
            do
            {

                Console.WriteLine("Enter 1 for Displaying list of Books ");
                Console.WriteLine("Enter 2 to view the description");
                Console.WriteLine("Enter 3 to edit the details");
                Console.WriteLine("Enter 4 to add a book");
                Console.WriteLine("Enter 5 to delete a book");
                Console.WriteLine("Enter 6 to Exit");


                Console.WriteLine("***Enter your CHOICE***");
                input = Convert.ToInt32(Console.ReadLine());

                switch (input)
                {
                    case 1:
                        dispaly(books);
                        break;

                    case 2:
                        Console.WriteLine("Enter Book Id to view the descrption \n");
                        int n = Convert.ToInt32(Console.ReadLine());
                        displayDescription(books, n);
                        break;

                    case 3:
                        Console.WriteLine("Enter Book Id to edit the details of book \n");
                        int a = Convert.ToInt32(Console.ReadLine());
                        editDetails(books, a);
                        break;

                    case 4:
                        Console.WriteLine("Book list before adding");
                        dispaly(books);
                        Console.WriteLine("\n");
                        BookStore b = new BookStore();

                        Console.WriteLine("Enter Id of the new book");
                        int id = Convert.ToInt32(Console.ReadLine());
                        b.bookId = id;

                        Console.WriteLine("Enter the name of the book");
                        string nbookName = Console.ReadLine();
                        b.bookName = nbookName;

                        Console.WriteLine("Enter Authors name");
                        string nauthorName = Console.ReadLine();
                        b.bookAuthor = nauthorName;

                        Console.WriteLine("Enter description of the book");
                        string description = Console.ReadLine();
                        b.bookDescription = description;

                        Console.WriteLine("Enter ISBN code");
                        Int64 isbnCode = Convert.ToInt64(Console.ReadLine());
                        b.bookIsbnCode = isbnCode;

                        Console.WriteLine("Enter price of the book");
                        double nprice = Convert.ToDouble(Console.ReadLine());
                        b.price = nprice;

                        addBook(books, b);
                        Console.WriteLine("\n");
                        Console.WriteLine("Book list after adding");
                        dispaly(books);
                        break;

                    case 5:
                        Console.WriteLine("Enter Book Id to delete the book");
                        int x = Convert.ToInt32(Console.ReadLine());
                        deleteDetails(books, x);
                        Console.WriteLine("Book list after deleting");
                        dispaly(books);
                        break;
                }
            } while (input != 6);



            Console.Read();





        }
    }
}
