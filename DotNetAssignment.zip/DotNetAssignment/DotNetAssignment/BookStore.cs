﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day11Assignment
{

    class BookStore
    {
        public int bookId;
        public string bookName, bookAuthor, bookDescription;
        public Int64 bookIsbnCode;
        public double price;

        public BookStore()
        {

        }

        public BookStore(int bookId, string bookName, string bookAuthor, string bookDescription, Int64 bookIsbnCode, double price)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.bookAuthor = bookAuthor;
            this.bookDescription = bookDescription;
            this.bookIsbnCode = bookIsbnCode;
            this.price = price;
        }

        public override string ToString()
        {
            return $"Id: {bookId} Name: {bookName} Author: {bookAuthor} Description: {bookDescription} ISBN Code: {bookIsbnCode} Price: {price}";
        }



    }


}
