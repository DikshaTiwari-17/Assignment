myApp.controller("bookEditController",function($scope,bookManage){
    
    $scope.saveEditBookDetailsEventHandler=function(){
        bookManage.editBook($scope.newBook)
        $scope.$emit("editNewBook")

    }
})