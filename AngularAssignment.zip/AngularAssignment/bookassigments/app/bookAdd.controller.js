myApp.controller("bookAddController",function($scope,bookManage){
    $scope.newBook = {}
    $scope.saveDetailsEventHandler=function(){
        bookManage.addBook($scope.newBook)
        $scope.$emit("addNewBook",$scope.newBook)

    }
})