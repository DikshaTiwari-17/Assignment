myApp.controller("bookDisplayController",function($scope,bookManage){
    $scope.bookArr=bookManage.getBookDetails();
    $scope.showDescription = false;
    $scope.showDescriptionEventHandler=function(book){
        $scope.showDescription = true;

    }
    $scope.showAddBook=false;
    $scope.showAddNewBookEventHandler=function(){
        $scope.showAddBook=true;
    }
    $scope.selectedBook={};
    $scope.showEditBook = false;
    $scope.editBookDetailsEventHandler=function(obj){
       
        $scope.showEditBook=true;
        $scope.selectedBook = obj ;
        console.log("Book selected for Editing ",obj);
    }

    $scope.$on("addNewBook",function(event,newBook){
        console.log(newBook)
        $scope.showAddEmployee=false;

    })
    $scope.$on("editNewBook",function(event){
        $scope.showEditEmployee=false;

    })




})